// import React from 'react';
// import { Box, Typography, makeStyles } from '@mui/material';

// const useStyles = Style((theme) => ({
//   root: {
//     backgroundColor: theme.palette.primary.main,
//     color: theme.palette.primary.contrastText,
//     padding: theme.spacing(2),
//     textAlign: 'center',
//     position: 'fixed',
//     bottom: 0,
//     width: '100%'
//   }
// }));

// const Footer = () => {
//   const classes = useStyles();

//   return (
//     <Box className={classes.root}>
//       <Typography variant="body2">&copy; {new Date().getFullYear()} Your Dashboard Name</Typography>
//     </Box>
//   );
// };

// export default Footer;
