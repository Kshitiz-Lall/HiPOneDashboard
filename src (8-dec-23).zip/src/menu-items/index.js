import dashboard from './dashboard';
import regressiontestgenerator from './regressiontestgenerator';

// ==============================|| MENU ITEMS ||============================== //

const menuItems = {
  items: [dashboard, regressiontestgenerator]
};

export default menuItems;
